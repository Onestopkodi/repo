# Random Movie Addon for Kodi

A Kodi script add-on to play a random movie from your movies library.

After install you'll find the script under Settings » Add-ons » Program Add-ons » Random Movie

I've added a setting for filtering types of movies to select from; all, watched, and unwatched.
You can even set the addon to ask each time you start it.