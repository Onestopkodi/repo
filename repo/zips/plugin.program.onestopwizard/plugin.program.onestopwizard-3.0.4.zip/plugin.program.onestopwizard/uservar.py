import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://www.dropbox.com/scl/fi/4hotjeooio0x17jul9mea/builds.xml?rlkey=28zl2oauq25ffy343zfvh3s20&dl=1'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://www.dropbox.com/s/urbbqiq9883usyo/notify.txt?dl=1'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
