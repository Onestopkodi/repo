import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://www.dropbox.com/s/2l5cwznsafd6fb1/builds.txt?dl=1'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://www.dropbox.com/s/urbbqiq9883usyo/notify.txt?dl=1'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
