import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://www.dropbox.com/s/92qw6gxx80msakg/builds.xml?dl=1'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://www.dropbox.com/s/urbbqiq9883usyo/notify.txt?dl=1'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
